#!/bin/bash

while true; do ./gpg-1.4.13 --yes -b echo.c; done
